| id  | name     | description           | version | author   | tags               |
| --- | -------- | --------------------- | ------- | -------- | ------------------ |
| 2   | ServiceA | Service A description | 1       | Bob      | tag1, tag2, tag3   |
| 3   | ServiceB | Service B details     | 2       | Bob      | production, stable |
| 4   | ServiceC | Service C description | 3       | Charlie  | beta, test         |
| 1   | ServiceX | Some description      | 1       | John Doe | example2, config2  |
(4 rows)